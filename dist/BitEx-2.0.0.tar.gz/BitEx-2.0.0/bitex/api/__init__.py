from bitex.api.rest import BitstampREST, BitfinexREST, BTCERest, BterREST
from bitex.api.rest import CCEXRest, CoincheckREST, CryptopiaREST, OKCoinREST
from bitex.api.rest import QuadrigaCXREST, HitBTCREST, RockTradingREST
from bitex.api.rest import BittrexREST, YunbiREST, QuoineREST, PoloniexREST
from bitex.api.rest import ItbitREST, KrakenREST, GDAXRest, GeminiREST, VaultoroREST


