from bitex.api.REST.rest import BitfinexREST, BitstampREST, BittrexREST
from bitex.api.REST.rest import BterREST, BTCERest, CCEXRest, CoincheckREST
from bitex.api.REST.rest import CryptopiaREST, GDAXRest, GeminiREST, HitBTCREST
from bitex.api.REST.rest import ItbitREST, KrakenREST, OKCoinREST, PoloniexREST
from bitex.api.REST.rest import QuadrigaCXREST, QuoineREST, RockTradingREST
from bitex.api.REST.rest import VaultoroREST, YunbiREST

