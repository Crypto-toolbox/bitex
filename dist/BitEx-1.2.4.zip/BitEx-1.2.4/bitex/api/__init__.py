import bitex.api.REST
import bitex.api.WSS

